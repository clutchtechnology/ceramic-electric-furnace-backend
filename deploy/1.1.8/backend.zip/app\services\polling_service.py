# ============================================================
# 文件说明: polling_service.py - 数据轮询核心服务
# ============================================================
# 功能:
#   1. 轮询服务状态管理 (启动/停止)
#   2. 批次号管理 (冶炼开始/停止)
#   3. 统一API接口 (供路由层调用)
# ============================================================
# 架构说明:
#   - polling_data_generator.py: Mock数据生成
#   - polling_data_processor.py: 数据处理和缓存管理
#   - polling_service.py: 核心服务和状态管理 (本文件)
# ============================================================

import threading
from datetime import datetime
from typing import Optional, Dict, Any

from config import get_settings

# 导入数据处理模块
from app.services.polling_data_processor import (
    init_parsers,
    get_latest_modbus_data,
    get_latest_arc_data,
    get_latest_status_data,
    get_latest_db41_data,
    get_latest_weight_data,
    get_valve_status_queues,
    get_buffer_status,
)

settings = get_settings()

# ============================================================
# Modbus RTU 配置
# ============================================================
MODBUS_PORT = "COM1"
MODBUS_BAUDRATE = 19200

# ============================================================
# 批次号管理 (Batch Code)
# ============================================================
# SM: 主动开始冶炼 (前端点击开始按钮)
# SX: 被动创建 (轮询时无批次号自动创建)
_current_batch_code: Optional[str] = None
_batch_start_time: Optional[datetime] = None
_is_smelting: bool = False
_batch_lock = threading.Lock()


# ============================================================
# 轮询服务状态管理
# ============================================================
def get_polling_status():
    """获取轮询服务状态"""
    from app.services.polling_loops_v2 import get_polling_loops_status
    loops_status = get_polling_loops_status()
    buffer_status = get_buffer_status()
    
    return {
        "is_running": loops_status['db1_running'],
        "batch_code": _current_batch_code,
        "start_time": _batch_start_time.isoformat() if _batch_start_time else None,
        "is_smelting": _is_smelting,
        "mode": "mock" if settings.mock_mode else "plc",
        "statistics": buffer_status['stats']
    }


# ============================================================
# 批次号管理函数
# ============================================================
def _generate_batch_code(prefix: str = "SX") -> str:
    """生成批次号"""
    now = datetime.now()
    return f"{prefix}{now.strftime('%Y%m%d-%H%M')}"


def ensure_batch_code() -> str:
    """确保有批次号，如果没有则被动创建"""
    global _current_batch_code, _batch_start_time, _is_smelting
    
    with _batch_lock:
        if _current_batch_code is None:
            _current_batch_code = _generate_batch_code("SX")
            _batch_start_time = datetime.now()
            _is_smelting = False
            print(f"📦 被动创建批次号: {_current_batch_code}")
        return _current_batch_code


def start_smelting(batch_code: Optional[str] = None) -> Dict[str, Any]:
    """开始冶炼 (前端调用)
    
    新批次开始时会重置蝶阀开度为0%
    """
    global _current_batch_code, _batch_start_time, _is_smelting
    
    with _batch_lock:
        if batch_code:
            _current_batch_code = batch_code
        else:
            _current_batch_code = _generate_batch_code("SM")
        _batch_start_time = datetime.now()
        _is_smelting = True
    
    # ========================================
    # 重置蝶阀开度 (新批次从0%开始)
    # ========================================
    try:
        from app.services.valve_calculator_service import reset_all_valve_openness
        reset_all_valve_openness(batch_code=_current_batch_code)
        print(f"🔄 蝶阀开度已重置 (批次: {_current_batch_code})")
    except Exception as e:
        print(f"⚠️ 重置蝶阀开度失败: {e}")
        
    print(f"🔥 开始冶炼, 批次号: {_current_batch_code}")
    
    return {
        'batch_code': _current_batch_code,
        'start_time': _batch_start_time.isoformat(),
        'is_smelting': _is_smelting
    }


def stop_smelting() -> Dict[str, Any]:
    """停止冶炼 (前端调用)"""
    global _current_batch_code, _batch_start_time, _is_smelting
    
    with _batch_lock:
        old_batch_code = _current_batch_code
        old_start_time = _batch_start_time
        _is_smelting = False
        _current_batch_code = None
        _batch_start_time = None
        
    print(f"⏹️ 停止冶炼, 批次号: {old_batch_code}")
    
    return {
        'batch_code': old_batch_code,
        'start_time': old_start_time.isoformat() if old_start_time else None,
        'end_time': datetime.now().isoformat(),
        'is_smelting': False
    }


def get_batch_info() -> Dict[str, Any]:
    """获取当前批次信息"""
    with _batch_lock:
        return {
            'batch_code': _current_batch_code,
            'start_time': _batch_start_time.isoformat() if _batch_start_time else None,
            'is_smelting': _is_smelting,
            'duration_seconds': (datetime.now() - _batch_start_time).total_seconds() if _batch_start_time else None
        }


# ============================================================
# 统一API接口 (供路由层调用)
# ============================================================
def get_polling_stats() -> Dict[str, Any]:
    """获取轮询统计信息"""
    buffer_status = get_buffer_status()
    
    return {
        'batch_code': _current_batch_code,
        'is_smelting': _is_smelting,
        'buffer_status': buffer_status
    }


# ============================================================
# 模块初始化
# ============================================================
def initialize_service():
    """初始化轮询服务"""
    print("🚀 初始化轮询服务...")
    init_parsers()
    print("✅ 轮询服务初始化完成")
