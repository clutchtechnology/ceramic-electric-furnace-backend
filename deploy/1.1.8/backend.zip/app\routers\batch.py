# ============================================================
# 文件说明: batch.py - 批次管理API路由
# ============================================================
# 接口:
#   POST /api/batch/start   - 开始冶炼
#   POST /api/batch/pause   - 暂停冶炼
#   POST /api/batch/resume  - 恢复冶炼
#   POST /api/batch/stop    - 停止冶炼
#   GET  /api/batch/status  - 获取状态（断电恢复用）
# ============================================================

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
from ..services.batch_service import get_batch_service


router = APIRouter(prefix="/api/batch", tags=["批次管理"])


# ============================================================
# 请求/响应模型
# ============================================================

class StartRequest(BaseModel):
    """开始冶炼请求"""
    batch_code: str = Field(..., description="批次编号，格式: 03-2026-01-15")
    
    class Config:
        json_schema_extra = {
            "example": {
                "batch_code": "03-2026-01-15"
            }
        }


class BatchResponse(BaseModel):
    """通用批次响应"""
    success: bool
    message: str
    batch_code: Optional[str] = None
    

class StatusResponse(BaseModel):
    """状态响应（用于断电恢复）"""
    state: str  # idle, running, paused, stopped
    is_smelting: bool  # 是否有活跃批次
    is_running: bool   # 是否正在写数据库
    batch_code: Optional[str]
    start_time: Optional[str]
    pause_time: Optional[str]
    elapsed_seconds: float
    total_pause_duration: float


# ============================================================
# API 路由
# ============================================================

@router.post("/start", response_model=BatchResponse, summary="开始冶炼")
async def start_smelting(request: StartRequest):
    """
    开始新的冶炼批次
    
    - 设置批次编号
    - 开始记录数据到数据库
    - 如果已有进行中的批次，返回错误
    """
    service = get_batch_service()
    result = service.start(request.batch_code)
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return BatchResponse(
        success=True,
        message=result["message"],
        batch_code=result["batch_code"]
    )


@router.post("/pause", response_model=BatchResponse, summary="暂停冶炼")
async def pause_smelting():
    """
    暂停当前冶炼
    
    - 保留批次编号
    - 暂停写入数据库
    - 记录暂停时长
    """
    service = get_batch_service()
    result = service.pause()
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return BatchResponse(
        success=True,
        message=result["message"],
        batch_code=result.get("batch_code")
    )


@router.post("/resume", response_model=BatchResponse, summary="恢复冶炼")
async def resume_smelting():
    """
    恢复暂停的冶炼
    
    - 继续使用原批次编号
    - 恢复写入数据库
    - 累计暂停时长
    """
    service = get_batch_service()
    result = service.resume()
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return BatchResponse(
        success=True,
        message=result["message"],
        batch_code=result.get("batch_code")
    )


@router.post("/stop", response_model=BatchResponse, summary="停止冶炼")
async def stop_smelting():
    """
    停止当前冶炼
    
    - 结束批次
    - 清除批次编号
    - 返回冶炼摘要
    """
    service = get_batch_service()
    result = service.stop()
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return BatchResponse(
        success=True,
        message=result["message"],
        batch_code=None
    )


@router.get("/status", response_model=StatusResponse, summary="获取状态")
async def get_status():
    """
    获取当前冶炼状态
    
    **用途**:
    - 前端启动时检查是否有未完成的批次（断电恢复）
    - 前端定期同步状态
    
    **断电恢复流程**:
    1. 前端启动时调用此接口
    2. 如果 is_smelting=true 且 state=paused，说明有未完成批次
    3. 前端显示恢复对话框，用户选择恢复或放弃
    """
    service = get_batch_service()
    status = service.get_status()
    
    return StatusResponse(**status)
